#!/bin/bash
# SloughGPT Enhanced WebUI Test Runner

set -e

echo "🧪 Running SloughGPT Enhanced WebUI Tests..."

# Install dependencies if needed
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv venv
fi

source venv/bin/activate
pip install -r requirements.txt

# Start server in background
python3 enhanced_webui.py &
SERVER_PID=$!

# Wait for server to start
sleep 3

# Run E2E tests
python3 e2e_test_suite.py
TEST_RESULT=$?

# Stop server
kill $SERVER_PID 2>/dev/null || true

# Exit with test result
exit $TEST_RESULT
