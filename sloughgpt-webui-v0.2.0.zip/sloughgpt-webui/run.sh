#!/bin/bash
# SloughGPT Enhanced WebUI Runner

set -e

PORT=${PORT:-8080}
HOST=${HOST:-0.0.0.0}

echo "🚀 Starting SloughGPT Enhanced WebUI..."
echo "📍 Server: http://$HOST:$PORT"
echo "📚 API Docs: http://$HOST:$PORT/docs"
echo "❤️  Health: http://$HOST:$PORT/api/health"

# Install dependencies if needed
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv venv
fi

source venv/bin/activate
pip install -r requirements.txt

# Run the application
python3 enhanced_webui.py
