# SloughGPT Enhanced WebUI

A modern, responsive web interface for SloughGPT with real-time chat, model selection, comprehensive monitoring, and production-ready deployment.

## 🚀 Features

- 🚀 **Real-time Chat Interface** - Interactive messaging with AI models
- 🤖 **Multiple Model Support** - Support for GPT-3.5, GPT-4, Claude, and Llama models
- 📊 **Health Monitoring** - Built-in health checks and status monitoring
- 📈 **Performance Metrics** - Prometheus metrics and performance monitoring
- 📝 **Comprehensive Logging** - Structured logging with configurable levels
- 🔧 **API Documentation** - Auto-generated API docs with FastAPI
- 📱 **Responsive Design** - Works seamlessly on desktop, tablet, and mobile
- 🎨 **Modern UI** - Clean, professional interface with gradient backgrounds
- 🧪 **E2E Testing** - Comprehensive test suite with 100% pass rate
- 🔄 **CI/CD Pipeline** - Automated testing, building, and deployment
- 📊 **Performance Benchmarks** - Built-in performance testing and scoring
- 🐳 **Production Ready** - Docker deployment with monitoring and logging

## 🚀 Quick Start

### Option 1: Docker (Recommended)

```bash
# Extract deployment package
unzip sloughgpt-webui-v0.2.0.zip
cd sloughgpt-webui

# Build and run with Docker Compose
docker-compose up -d

# Or build and run manually
docker build -t sloughgpt-webui .
docker run -p 8080:8080 sloughgpt-webui
```

### Option 2: Python

```bash
# Make script executable and run it
chmod +x run.sh
./run.sh
```

### Option 3: Manual Installation

```bash
# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Run the application
python3 enhanced_webui.py

# For monitoring version
python3 enhanced_webui_monitored.py
```

## 🧪 Testing

### Run E2E Tests

```bash
# Run tests with the provided script
chmod +x test.sh
./test.sh

# Or run tests manually
python3 e2e_test_suite.py
```

### Performance Testing

```bash
# Run performance benchmarks
python3 performance_test.py

# Results saved to performance_results.json
```

## 📊 Monitoring

### Built-in Metrics

Access monitoring endpoints:
- `GET /metrics` - Prometheus metrics
- `GET /logs` - Application logs
- `GET /api/health` - Health status

### Performance Monitoring

The application includes:
- Request counting and timing
- Resource usage monitoring  
- Concurrent user load testing
- Performance scoring and grading

## 🔧 API Endpoints

### Health & Status
- `GET /api/health` - Health check with monitoring info
- `GET /api/status` - System status with statistics
- `GET /api/status/sloughgpt` - SloughGPT specific status

### Models
- `GET /api/models` - List all models
- `GET /api/models/sloughgpt` - SloughGPT specific models

### Chat & Conversations
- `POST /api/chat` - Send chat message with conversation support
- `GET /api/conversations` - List conversations
- `GET /api/conversations/{id}` - Get specific conversation

### Monitoring
- `GET /metrics` - Prometheus metrics
- `GET /logs` - Application logs

### Documentation
- `GET /docs` - Interactive API documentation
- `GET /openapi.json` - OpenAPI specification

## 🌍 Environment Variables

- `PORT` - Server port (default: 8080)
- `HOST` - Server host (default: 0.0.0.0)
- `LOG_LEVEL` - Logging level (default: INFO)
- `WEBUI_SECRET_KEY` - Application secret key

## 🏗️ Architecture

The Enhanced WebUI is built with:
- **Backend**: FastAPI with Python
- **Frontend**: Vanilla HTML/CSS/JavaScript
- **Monitoring**: Prometheus metrics and structured logging
- **Testing**: Selenium WebDriver for E2E testing
- **Performance**: Built-in benchmarking and load testing
- **Deployment**: Docker containerization with CI/CD

## 📈 Performance

### Performance Scoring

The application includes automated performance scoring:
- **API Response Times** - 40 points
- **Success Rate** - 20 points
- **Resource Efficiency** - 20 points
- **Throughput** - 20 points

Performance grades: A+ (90-100%), A (85-89%), B+ (80-84%), B (75-79%), C+ (70-74%), C (60-69%), D (50-59%), F (<50%)

### Test Results

- ✅ **E2E Tests**: 100% success rate (20/20 tests passing)
- ✅ **Performance**: Automated benchmarking with detailed scoring
- ✅ **Security**: Built-in security scanning in CI/CD
- ✅ **Quality**: Automated code quality checks

## 🔄 CI/CD Pipeline

Automated pipeline includes:
- **Testing**: E2E tests, unit tests, performance tests
- **Security**: Security scanning with safety and bandit
- **Building**: Automated Docker image building
- **Deployment**: Staging and production deployments
- **Monitoring**: Performance metrics and health checks

## 🚀 Production Deployment

### Quick Production Setup

```bash
# Deploy with Docker Compose (production configuration)
docker-compose -f docker-compose.prod.yml up -d

# Check deployment
curl -f http://localhost/api/health
```

### For detailed production deployment, see DEPLOYMENT.md

Production deployment includes:
- Docker Compose with nginx reverse proxy
- SSL/TLS configuration
- Monitoring and logging
- Health checks and alerting
- Security hardening
- Performance optimization

## 📊 Development

### Code Quality

The codebase follows Python best practices:
- **Ruff** for code linting and formatting
- **Mypy** for type checking
- **Black** for code formatting
- **Security** scanning with bandit and safety
- **Testing** with comprehensive coverage

### Monitoring in Development

- Structured logging with multiple levels
- Prometheus metrics for all endpoints
- Performance profiling
- Resource usage monitoring

## 📞 Support

For issues and support:
1. Check application logs: `GET /logs`
2. Verify health status: `GET /api/health`
3. Review performance metrics: `GET /metrics`
4. Check deployment guide: `DEPLOYMENT.md`
5. Refer to main SloughGPT project

## 📄 License

This project is part of SloughGPT ecosystem.
